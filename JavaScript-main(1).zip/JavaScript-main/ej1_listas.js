    // Crea una lista de números pares del 2 al 20 utilizando un bucle while.

    // Crea una lista de números impares del 1 al 19 utilizando un bucle for.
    
    // Crea una lista de comida.
    
    // Agrega un elemento al principio de la lista de comida que creaste en el ejercicio anterior.
    
    // Accede al segundo elemento de la lista de comida y cambia su valor por otro diferente.
    
    // Recorre la lista de comida utilizando un bucle while y muestra cada elemento en la consola.
    
    // Crea una función que reciba una lista como parámetro y devuelva el último elemento de la lista.
    
    // Crea una función que reciba una lista y un elemento como parámetros y agregue el elemento a la lista si no se encuentra en ella.
    
    // Crea una función que reciba una lista como parámetro y devuelva una nueva lista con los elementos de la lista original en orden inverso.
    
    // Crea una función que reciba una lista de números como parámetro y devuelva la suma de todos los números de la lista.
    
    // Crea una función que reciba una lista de números como parámetro y devuelva la media de todos los números de la lista.

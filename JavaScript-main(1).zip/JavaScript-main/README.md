**Ejercicios usando listas con Javascript**
> 1. Realiza una copia del repositorio (FORK)
>>2. Edita las respuestas (ej1_listas.js).
![This is an image](https://cdn.pixabay.com/photo/2015/04/23/17/41/javascript-736400_960_720.png)
